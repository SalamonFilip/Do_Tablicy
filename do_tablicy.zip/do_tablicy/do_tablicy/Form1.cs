﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Do_Tablicy : Form
    {
        public Do_Tablicy()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int qua = int.Parse(textBox1.Text);
            if (qua == 0)
            {
                MessageBox.Show("Przykro mi, ale nie ma klasy o 0 ilości uczniów :C");
            }
            Random rnd = new Random();
            int randix = rnd.Next(1, qua);
            textBox2.Text = randix.ToString();

           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
        }
    }
}
